import { Component } from '@angular/core';
import { SideNavComponent } from './components/side-nav/side-nav.component';
import { ChatWindowComponent } from './components/chat-window/chat-window.component';

@Component({
  selector: 'app-root',
  imports: [ SideNavComponent,ChatWindowComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'fbGPT';
}
